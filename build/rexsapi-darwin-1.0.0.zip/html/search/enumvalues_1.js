var searchData=
[
  ['boolean_0',['BOOLEAN',['../namespacerexsapi.html#a45ebd07bd387585c3e1205fb840e6a23ac48d5da12d702e73d6966069f2687376',1,'rexsapi']]],
  ['boolean_5farray_1',['BOOLEAN_ARRAY',['../namespacerexsapi.html#a45ebd07bd387585c3e1205fb840e6a23a077591e5756f9a467b2d9bb878b4b380',1,'rexsapi']]],
  ['boolean_5fmatrix_2',['BOOLEAN_MATRIX',['../namespacerexsapi.html#a45ebd07bd387585c3e1205fb840e6a23affb050b273e0a2c273a6c22655a4c086',1,'rexsapi']]]
];
