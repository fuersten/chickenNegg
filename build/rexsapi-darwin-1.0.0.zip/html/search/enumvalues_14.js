var searchData=
[
  ['xml_0',['XML',['../namespacerexsapi.html#a70ac4af1fdd2764837d36d71d6d0d9bfa3501bb093d363810b671059b9cfed3f8',1,'rexsapi::XML()'],['../namespacerexsapi.html#ad295c43d307d6148d6987ddfa1ade865a3501bb093d363810b671059b9cfed3f8',1,'rexsapi::XML()']]]
];
