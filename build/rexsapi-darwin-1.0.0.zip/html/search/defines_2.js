var searchData=
[
  ['pugixml_5fheader_5fonly_0',['PUGIXML_HEADER_ONLY',['../_xml_8hxx.html#a50b0860df1126fa0e883a42c43a9c789',1,'Xml.hxx']]]
];
