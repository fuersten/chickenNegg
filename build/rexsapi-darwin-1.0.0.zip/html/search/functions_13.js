var searchData=
[
  ['xmlencodecodedarray_0',['xmlEncodeCodedArray',['../namespacerexsapi.html#a07c5d0c7902bace267d736a9c7912c71',1,'rexsapi']]],
  ['xmlencodecodedmatrix_1',['xmlEncodeCodedMatrix',['../namespacerexsapi.html#a80b01dc5fdc9cedb3e6d4416e9880441',1,'rexsapi']]]
];
