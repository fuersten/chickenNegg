var searchData=
[
  ['bool_0',['Bool',['../structrexsapi_1_1_bool.html',1,'rexsapi']]]
];
