var searchData=
[
  ['ziparchive_0',['ZipArchive',['../classrexsapi_1_1detail_1_1_zip_archive.html#a4930349ceb9fcaae4bf822685d997d20',1,'rexsapi::detail::ZipArchive::ZipArchive(std::filesystem::path archive, const TExtensionChecker &amp;extensionChecker)'],['../classrexsapi_1_1detail_1_1_zip_archive.html#ae2090768bc5f05a704f3b6f5c4694334',1,'rexsapi::detail::ZipArchive::ZipArchive(const ZipArchive &amp;)=delete'],['../classrexsapi_1_1detail_1_1_zip_archive.html#a95896faebaaf797195997017c23dd9a0',1,'rexsapi::detail::ZipArchive::ZipArchive(ZipArchive &amp;&amp;)=delete']]]
];
