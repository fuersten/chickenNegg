var searchData=
[
  ['xsdschemans_0',['xsdSchemaNS',['../namespacerexsapi_1_1detail.html#ae62ae8dd819379d6a80f34c91746b79d',1,'rexsapi::detail']]]
];
