var searchData=
[
  ['loadspectrum_2ehxx_0',['LoadSpectrum.hxx',['../_load_spectrum_8hxx.html',1,'']]]
];
