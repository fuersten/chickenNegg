var searchData=
[
  ['matchesvaluetype_0',['matchesValueType',['../classrexsapi_1_1_t_value.html#a054b1b9056918f579ac4540b5ed2a166',1,'rexsapi::TValue']]]
];
