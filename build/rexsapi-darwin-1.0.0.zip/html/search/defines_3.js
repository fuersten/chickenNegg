var searchData=
[
  ['valijson_5fuse_5fexceptions_0',['VALIJSON_USE_EXCEPTIONS',['../_json_schema_validator_8hxx.html#af1373759fc8d7ab28c080ae2b7ef142a',1,'JsonSchemaValidator.hxx']]]
];
