var searchData=
[
  ['ptr_0',['Ptr',['../classrexsapi_1_1detail_1_1_t_simple_type.html#ac94fc33f45c3c73d900f000db2f3b31c',1,'rexsapi::detail::TSimpleType::Ptr()'],['../classrexsapi_1_1detail_1_1_t_element_type.html#a8e679f24603b1e15c4c4d1c76bc34c36',1,'rexsapi::detail::TElementType::Ptr()']]]
];
