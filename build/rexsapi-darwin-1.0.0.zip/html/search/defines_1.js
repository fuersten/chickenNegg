var searchData=
[
  ['miniz_5fheader_5ffile_5fonly_0',['MINIZ_HEADER_FILE_ONLY',['../_zip_archive_8hxx.html#aa0b5c57a0e5841814131917c6093f0e6',1,'ZipArchive.hxx']]],
  ['miniz_5fno_5fzlib_5fapis_1',['MINIZ_NO_ZLIB_APIS',['../_zip_archive_8hxx.html#a3c6e74ff876781d1c19a31ed3aba0342',1,'ZipArchive.hxx']]],
  ['miniz_5fno_5fzlib_5fcompatible_5fnames_2',['MINIZ_NO_ZLIB_COMPATIBLE_NAMES',['../_zip_archive_8hxx.html#ae390db9f736996032baf414e873b41f5',1,'ZipArchive.hxx']]]
];
